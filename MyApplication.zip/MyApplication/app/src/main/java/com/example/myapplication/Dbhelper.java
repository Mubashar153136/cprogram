package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Dbhelper extends SQLiteOpenHelper {
    public Dbhelper(Context context) {
        super( context, "Mubashar.db" , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create Table  mubashardetail(name text primary key,lastname text,gender text,program text,matric text,inter text,bs text,city text ) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists mubashardetail");

    }
    public  boolean  insertdata(String name ,String lastname,String gender,String program,String matric,String inter,String bs,String city)
    {

        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put("name",name);
        contentValues.put("lastname",lastname);
        contentValues.put("gender",gender);
        contentValues.put("program",program);
        contentValues.put("inter",inter);
        contentValues.put("matric",matric);
        contentValues.put("inter",inter);
        contentValues.put("bs",bs);
        contentValues.put("city",city);

        long result= DB.insert("mubashardetail",null,contentValues);
        if (result==-1)
        {
            return false;
        }
        else {
            return true;
        }

    }


    public  boolean  updatedata(String name ,String lastname,String gender,String program,String matric,String inter,String bs,String city)
    {

        SQLiteDatabase DB=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put("name",name);
        contentValues.put("lastname",lastname);
        contentValues.put("gender",gender);
        contentValues.put("program",program);
        contentValues.put("inter",inter);
        contentValues.put("matric",matric);
        contentValues.put("inter",inter);
        contentValues.put("bs",bs);
        contentValues.put("city",city);
        Cursor cursor=DB.rawQuery("Select * from mubashardetail where name=?",new String[] {name});
        if (cursor.getCount()>0) {

            long result = DB.update("mubashardetail", contentValues, "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else {
            return false;
        }

    }
    public  boolean  deletedata(String name )
    {

        SQLiteDatabase DB=this.getWritableDatabase();


        Cursor cursor=DB.rawQuery("Select * from mubashardetail where name=?",new String[] {name});
        if (cursor.getCount()>0) {

            long result = DB.delete("mubashardetail", "name=?", new String[]{name});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        else {
            return false;
        }

    }
    public Cursor getdata()
    {

        SQLiteDatabase DB=this.getWritableDatabase();


        Cursor cursor=DB.rawQuery("Select * from mubashardetail",null);
        return cursor;
    }

}
