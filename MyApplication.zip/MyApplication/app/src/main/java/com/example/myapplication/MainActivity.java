package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
Dbhelper DB;
    Spinner citySpinner;
    TextView maleView,femaleView;
    Switch s;
    CheckBox matric,inter,bs;
    RadioButton r1,r2;
    Button insert,update,delete,view;
    public void validate(View view){
        //TextInput

        TextInputEditText firstname=findViewById((R.id.firstname));
         TextInputEditText lastname=findViewById(R.id.lastname);

        if(firstname.getText().toString().trim().isEmpty()){
            firstname.setError("Enter first name");
        }else if(lastname.getText().toString().trim().isEmpty()){
            lastname.setError("Enter last name");
        }else{
            if(r1.isChecked()){
                if(matric.isChecked() && inter.isChecked()){
                    if(bs.isChecked()){
                        Toast.makeText(getApplicationContext(),"you cannot select BS with BS",Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(),"Matric and Inter is required with BS",Toast.LENGTH_LONG).show();
                }

            }else if(r2.isChecked()){
                if(!(matric.isChecked() && inter.isChecked() && bs.isChecked())){
                    Toast.makeText(getApplicationContext(),"Matric, Inter and BS is required with MS",Toast.LENGTH_LONG).show();
                }
            }else{
                Toast.makeText(getApplicationContext(),"Select Program",Toast.LENGTH_LONG).show();
            }
        }


    }

    public void changeGender(View view){
         s=(Switch)view;
        if(s.isChecked()){
            maleView.setVisibility(View.VISIBLE);
            femaleView.setVisibility(View.INVISIBLE);
        }else{
            femaleView.setVisibility(View.VISIBLE);
            maleView.setVisibility(View.INVISIBLE);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextInputEditText firstname=findViewById((R.id.firstname));
        TextInputEditText lastname=findViewById(R.id.lastname);
        citySpinner=findViewById(R.id.citySpinner);
        maleView=findViewById(R.id.male_view);
        femaleView=findViewById(R.id.female_view);
        s=findViewById(R.id.genderSwitch);
        r1=findViewById(R.id.radioButton2);
        r2=findViewById(R.id.radioButton);

        matric=findViewById(R.id.matricCheckBox);
        inter=findViewById(R.id.interCheckBox);
        bs=findViewById(R.id.bsCheckBox);
        insert=findViewById(R.id.InsertBtn);
        delete=findViewById(R.id.Deletebtn);
        update=findViewById(R.id.Updatebtn);
        view=findViewById(R.id.Viewbtn);
        DB=new Dbhelper(this);

        ArrayList<String> cities=new ArrayList<String>();
        cities.add("Gujranwala");
        cities.add("Daska");
        cities.add("Multan");
        cities.add("Lahore");
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,cities);

        citySpinner.setAdapter(adapter);
       insert.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String name= firstname.getText().toString();
               String last= lastname.getText().toString();
               String gender="female";
               if(s.isChecked())
               {
                   gender="Male";
               }
               String program="BS";
               if(r2.isChecked())
               {
                   program="MS";
               }
               String matrc="";
               if(matric.isChecked())
               {
                   matrc="matric";

               }
               String intermd="";
               if(inter.isChecked())
               {
                   intermd="Fsc";
               }
               String bachlor="";
               if(bs.isChecked())
               {
                   bachlor="BS";
               }
               String city=citySpinner.getSelectedItem().toString();
               boolean checinsert=DB.insertdata(name,last,gender,program,matrc,intermd,bachlor,city);
               if (checinsert==true)
               {
                   Toast.makeText(MainActivity.this,"New Data inserted",Toast.LENGTH_SHORT).show();

               }
               else {
                   Toast.makeText(MainActivity.this,"New Data Not inserted",Toast.LENGTH_SHORT).show();

               }




           }
       });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name= firstname.getText().toString();
                String last= lastname.getText().toString();
                String gender="female";
                if(s.isChecked())
                {
                    gender="Male";
                }
                String program="BS";
                if(r2.isChecked())
                {
                    program="MS";
                }
                String matrc="";
                if(matric.isChecked())
                {
                    matrc="matric";

                }
                String intermd="";
                if(inter.isChecked())
                {
                    intermd="Fsc";
                }
                String bachlor="";
                if(bs.isChecked())
                {
                    bachlor="BS";
                }
                String city=citySpinner.getSelectedItem().toString();
                boolean checupdate=DB.updatedata(name,last,gender,program,matrc,intermd,bachlor,city);
                if (checupdate==true)
                {
                    Toast.makeText(MainActivity.this,"user data updated",Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(MainActivity.this,"user data not updated",Toast.LENGTH_SHORT).show();

                }




            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name= firstname.getText().toString();
                String last= lastname.getText().toString();
                String gender="female";
                if(s.isChecked())
                {
                    gender="Male";
                }
                String program="BS";
                if(r2.isChecked())
                {
                    program="MS";
                }
                String matrc="";
                if(matric.isChecked())
                {
                    matrc="matric";

                }
                String intermd="";
                if(inter.isChecked())
                {
                    intermd="Fsc";
                }
                String bachlor="";
                if(bs.isChecked())
                {
                    bachlor="BS";
                }
                String city=citySpinner.getSelectedItem().toString();
                boolean checdelete=DB.deletedata(name);
                if (checdelete==true)
                {
                    Toast.makeText(MainActivity.this,"Data Deleted",Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(MainActivity.this,"Not Deleted",Toast.LENGTH_SHORT).show();

                }




            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor result=DB.getdata();
                if (result.getCount()==0)
                {
                    Toast.makeText(MainActivity.this,"Data Not exist",Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer=new StringBuffer();
                while (result.moveToNext())
                {
                    buffer.append("FirstName :"+result.getString(0)+"\n");
                    buffer.append("LastName :"+result.getString(1)+"\n");
                    buffer.append("Gender :"+result.getString(2)+"\n");
                    buffer.append("Program :"+result.getString(3)+"\n");
                    buffer.append("Matric  :"+result.getString(4)+"\n");
                    buffer.append("FSC :"+result.getString(5)+"\n");
                    buffer.append("Bachlor :"+result.getString(6)+"\n");
                    buffer.append("City :"+result.getString(7)+"\n\n");


                }
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("My Data");
                builder.setMessage(buffer.toString());
                builder.show();




            }
        });



    }
}