<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bongo";
if($_POST>0){

$conn = new mysqli("$servername", "$username", "$password", "$dbname");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$result = mysqli_query($conn,"SELECT * FROM signup WHERE email='" . $_POST["email"] . "' and password = '". $_POST["password"]."'");
    $count  = mysqli_num_rows($result);
    if($count==0) {
        $message = "Invalid Username or Password!";
    } else {
        $message = "You are successfully authenticated!";
    }
}
}



// $email=$_POST['email'];


// $password=$_POST['password'];



// $salt="bongo";
// $password_encrypted= sha1($password.$salt);

// $result=mysql_query($conn,"SELECT  * FROM signup WHERE email='".$email."' and password = '".$password_encrypted."' ");
// $count  = mysqli_num_rows($result);

//     if($count==0) {
//         $message = "Invalid UserEmail or Password!";
//     } else {
//         $message = "You are successfully authenticated!";
//     }


?>