<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bongo";

$conn = new mysqli("$servername", "$username", "$password", "$dbname");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$name=$_POST['name'];



$email=$_POST['email'];


$password=$_POST['password'];



$salt="bongo";
$password_encrypted= sha1($password.$salt);


$query ="INSERT INTO signup (name,email,password) value ('".$name."','".$email."','".$password_encrypted."')";
$data=mysqli_query($conn,$query);
if($data)
{
?>
<script>
    alert("values inserted");
</script>
<?php

}
else{
?>
<script>
    alert("values not inserted");
</script>

<?php
}

?>